﻿namespace CompteApp
{
    public class Compte
    {
        public static int nombreCompte = 0;
        public readonly string numero;
        public double solde;
        public Compte(string numero)
        { this.numero = numero; nombreCompte++; solde = 50; }
    }
}
