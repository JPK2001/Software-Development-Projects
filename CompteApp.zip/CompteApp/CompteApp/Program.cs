﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompteApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Compte c1 = new Compte("90212");
            Compte c2 = new Compte("90213");
            Compte c3 = new Compte("90214");
            Console.WriteLine("Le nombre de compte créer est de: "+Compte.nombreCompte);

            Console.ReadKey();
        }
    }
}
