﻿namespace Exercice.TP_Atelier_4
{
    internal interface IAffichable
    {
     void Afficher();
    }
}
