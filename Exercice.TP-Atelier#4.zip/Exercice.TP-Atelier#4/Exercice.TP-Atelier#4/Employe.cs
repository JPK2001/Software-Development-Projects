﻿using System;

namespace Exercice.TP_Atelier_4
{
    internal class Employe : Personne, IAffichable
    {
        private double _salaire;
        public double Salaire { get { return _salaire; } }
        public Employe(string nom, string prenom, double salaire) : base(nom, prenom) { _salaire = salaire; }
        public override string ToString()
                {
                    return base.ToString() + $" Salaire: {_salaire}$";
                }
        public void Afficher()
                { Console.WriteLine(ToString()); }
        public override double CalculerRevenu() { return _salaire; }
    }
}
