﻿namespace Exercice.TP_Atelier_4
{
    internal abstract class Personne
    {
        private string _nom;
        private string _prenom;
        public string Nom { get { return _nom; } set { _nom  = value; } }
                public string Prenom { get { return _prenom; } set { _prenom = value; } }
         protected Personne(string nom, string prenom)
                {
                    _nom = nom;
                    _prenom = prenom;
                }

        public override string ToString()
                {
                    return $"Nom: {_nom} Prénom: {_prenom}";
                }

        public abstract double CalculerRevenu();
    }
}
