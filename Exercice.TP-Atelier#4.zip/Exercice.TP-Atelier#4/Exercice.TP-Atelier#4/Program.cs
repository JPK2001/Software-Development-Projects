﻿using System;
using System.Collections.Generic;

namespace Exercice.TP_Atelier_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Personne> personnes = new List<Personne>();
            personnes.Add(new Employe("Dubois", "Jean", 4500)); 
            personnes.Add(new Vendeur("Amadou", "Ali", 3000, 0.015, 50540.52)); 
            Console.WriteLine("Nombre de personnes :" + personnes.Count);
            personnes.Add(new Employe("Mia", "Sarah", 6700.98)); 
            personnes.Add(new Vendeur("Adam", "Léo", 4320, 0.02, 7840.99));
            foreach (Personne p in personnes)
            {
                ((IAffichable)p).Afficher();
                Console.WriteLine($"Son revenu : {p.CalculerRevenu()}$");
            }
            Console.ReadKey();
        }
    }
}
