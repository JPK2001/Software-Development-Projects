﻿using System;

namespace Exercice.TP_Atelier_4
{
    internal class Vendeur : Personne, IAffichable
    {
        private double _salaire;
        private double _commission;
        private double _chiffreAffaires;
        public double Salaire { get { return _salaire; } }
        public double ChiffreAffaires { get { return _chiffreAffaires; } set { _chiffreAffaires = value; } }
        public Vendeur(string nom, string prenom, double salaire) : base(nom, prenom)
        { _salaire = salaire; }
        public Vendeur(string nom, string prenom, double salaire, double commission, double chiffreAffaires) : base(nom, prenom)
        {
            _salaire = salaire;
            _commission = commission; _chiffreAffaires = chiffreAffaires;
        }
        public override string ToString()
        {
            return base.ToString() + $" Salaire :{_salaire}$ Commission: {_commission} Chiffre d'affaires: {+_chiffreAffaires}$";
        }
        public void Afficher() { Console.WriteLine(ToString()); }
        public override double CalculerRevenu() {
            return _salaire + _commission * _chiffreAffaires;
        }
    }
}
