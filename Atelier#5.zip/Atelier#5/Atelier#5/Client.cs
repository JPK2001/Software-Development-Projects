﻿using System;

namespace Atelier_5
{
    public class Client
    {
        private string nom;
        private string identifiant;

        public Client(string nom, string identifiant)
        {
            this.nom = nom;
            this.identifiant = identifiant;
        }

        public void MiseAJourCompte(string compte, string operation, double ancienSolde, double nouveauSolde)
        {
            Console.WriteLine($"Compte : {compte}, Opération : {operation}, Ancien Solde : {ancienSolde}$, Nouveau Solde : {nouveauSolde}$");
        }
    }
}
