﻿using System;

namespace Atelier_5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Client c1 = new Client("Sarah Maxime", "BC252"); 
            Compte cpt1 = new Compte("815-25142", 2500, c1); 
            cpt1.CompteOperationNotificationEvent += c1.MiseAJourCompte;

            Client c2 = new Client("Adam Amal", "MW9825"); 
            Compte cpt2 = new Compte("829-95800", 0, c2); 
            cpt2.CompteOperationNotificationEvent += c2.MiseAJourCompte;

            cpt1.Debiter(500);
            cpt2.Crediter(1500);
            cpt1.Crediter(2500);
            cpt2.Debiter(600);

            Console.ReadKey();
        }
    }
}
