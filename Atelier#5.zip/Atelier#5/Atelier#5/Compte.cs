﻿namespace Atelier_5
{
    public class Compte
    {
        private string numeroCompte;
        private double solde;
        private Client proprietaire;

        public delegate void CON(string compte, string operation, double ancienSolde, double nouveauSolde);

        public event CON CompteOperationNotificationEvent;

        public Compte(string numeroCompte, double solde, Client proprietaire)
        {
            this.numeroCompte = numeroCompte;
            this.solde = solde;
            this.proprietaire = proprietaire;
        }

        public void Debiter(double montant)
        {
            double ancienSolde = this.solde;
            this.solde -= montant;
            OnCON(this.numeroCompte, "Débit", ancienSolde, this.solde);
        }

        public void Crediter(double montant)
        {
            double ancienSolde = this.solde;
            this.solde += montant;
            OnCON(this.numeroCompte, "Crédit", ancienSolde, this.solde);
        }

        protected virtual void OnCON(string compte, string operation, double ancienSolde, double nouveauSolde)
        {
            CompteOperationNotificationEvent?.Invoke(compte, operation, ancienSolde, nouveauSolde);
        }
    }
}
