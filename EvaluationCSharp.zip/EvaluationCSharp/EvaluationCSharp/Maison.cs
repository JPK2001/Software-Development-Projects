﻿using System;

namespace EvaluationCSharp
{
    // Maison class inherits from Batiment class and implements IAffichable interface
    internal class Maison : Batiment
    {
        public double NbrPieces { get; set; }
        protected double PrixMaison { get; set; }

        // Constructor with no parameters
        public Maison(string adresse):base(adresse)
        {
            NbrPieces = 0;
            PrixMaison = 0.0;
        }

        // Constructor with parameters
        public Maison(double nbrPieces, double prixMaison,string adresse):base(adresse)
        {
            NbrPieces = nbrPieces;
            PrixMaison = prixMaison;
        }

        // Redefining the ToString method
        public new string ToString()
        {
            return $"Number of Rooms: {NbrPieces}, Price of House: {PrixMaison}";
        }

        // Implementing the AfficherInfo method
        public new void AfficherInfos()
        {
            Console.WriteLine(ToString());
            Console.WriteLine($"The taxes to be paid for this house are {CalculerTaxes()}$");
        }

        public override double CalculerTaxes()
        {
            return PrixMaison * 0.09;
        }
    }
}
