﻿using System;

namespace EvaluationCSharp
{
    internal abstract class Batiment : IAffichable
    {
        protected string Adresse { get; set; }

        //TODO: 1 - Ajouter le ou les constructeurs nécessaires pour la suite de ce programme
        protected Batiment(string adresse)
        {
            Adresse = adresse;
        }

        public new string ToString()
        { return $"adresse : {Adresse}"; }

        public abstract double CalculerTaxes();
        public void AfficherInfos()
        {
            Console.WriteLine(ToString());
            Console.WriteLine($"Les taxes à payées pour cet immeuble sont {CalculerTaxes()}$");
        }
    }
}