﻿using System;
using System.Collections.Generic;

namespace EvaluationCSharp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //TODO: 9 - Déclarer une liste de bâtiments
            List<Batiment> list = new List<Batiment>();

            Maison m1 = new Maison(3.5, 452000, "60 Distillery Lane");
            Maison m2 = new Maison(4.5, 720000, "134 Albion RD");
            Immeuble im1 = new Immeuble(13, 350000, "2245 Islington Ave");
            Immeuble im2 = new Immeuble(25, 229000, "100 Marmora St");

            //TODO: 10 - Ajouter ces objets à la  liste
            // Add these objects to the list
            list.Add(m1);
            list.Add(m2);
            list.Add(im1);
            list.Add(im2);

            //TODO: 11 - Faire une boucle pour appeler AfficherInfos()
            // Loop to call AfficherInfos()
            foreach (var batiment in list)
            {
                batiment.AfficherInfos();
                Console.WriteLine();
            }

            Console.ReadKey();
        }
    }
}
