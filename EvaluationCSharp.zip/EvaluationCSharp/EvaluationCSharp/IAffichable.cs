﻿namespace EvaluationCSharp
{
    internal interface IAffichable
    {
        void AfficherInfos();
    }
}