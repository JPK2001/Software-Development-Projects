﻿using System;

namespace EvaluationCSharp
{
    //TODO: 2 - la classe immeuble hérite de la classe bâtiment et implémente l'interface Affichable
    internal class Immeuble : Batiment
    {

        public int NbrApparts { get; set; }
        protected double PrixApprt { get; set; }

        //TODO: 3 - Ajouter le ou les constructeurs nécessaires pour la suite de ce programme
        // Constructor with no parameters
        public Immeuble(string adresse) : base(adresse)
        {
            NbrApparts = 0;
            PrixApprt = 0.0;
        }

        // Constructor with parameters
        public Immeuble(int nbrApparts, double prixApprt, string adresse) : base(adresse)
        {
            NbrApparts = nbrApparts;
            PrixApprt = prixApprt;
        }

        //TODO: 4 - Redéfinir la méthode ToString pour qu'elle retourne les informations de cette classe
        public new string ToString()
        {  return $"Cette immeuble dispose de {NbrApparts} appartements qui coutent {PrixApprt} l'unité"; }


        public new void AfficherInfos()
        {
            Console.WriteLine(ToString());
            Console.WriteLine($"Les taxes à payées pour cet immeuble sont {CalculerTaxes()}$");
        }


        public override double CalculerTaxes()
        {

            return PrixApprt * NbrApparts * 0.07;
        }


    }
}
